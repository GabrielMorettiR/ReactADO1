import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  Pressable,
  Image,
  Modal,
} from 'react-native';
import Constants from 'expo-constants';

const ShowDetalhes = ({ display, toogleModal, nomeCompleto, email }) => (
  <Modal
    animationType="slide"
    transparent={true}
    visible={display}
    onRequestClose={toogleModal}>
    <View style={styles.centeredView}>
      <View style={styles.modalView}>
        <Pressable onPress={toogleModal}>
          <Text>
            {nomeCompleto} - {email}
          </Text>
        </Pressable>
      </View>
    </View>
  </Modal>
);

const Pessoa = ({ nome, email, link }) => {
  //state para controle do Modal
  const [modal, setModal] = React.useState(false);

  function mudaModal() {
    setModal(!modal);
  }

  return (
    <View>
      <ShowDetalhes
        display={modal}
        toogleModal={mudaModal}
        nomeCompleto={nome}
        email={email}
      />

      <Pressable onPress={mudaModal}>
        <Image
          style={styles.tinyLogo}
          source={{
            uri: link,
          }}
        />

        <Text style={styles.paragraph}>{nome}</Text>
      </Pressable>
    </View>
  );
};

const DATA = [
  {
    id: 1,
    email: 'gmoretti@gmail.com',
    first_name: 'Gabriel',
    last_name: 'Moretti',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
  {
    id: 2,
    email: 'brunomarzio@hotmail.com',
    first_name: 'Bruno',
    last_name: 'de Marzio',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
  {
    id: 3,
    email: 'takano@gmail.com',
    first_name: 'Ivan',
    last_name: 'Takano',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
  {
    id: 4,
    email: 'santiago@outlook.com',
    first_name: 'Lucas',
    last_name: 'Santiago',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
  {
    id: 5,
    email: 'gregazio@gmail.com',
    first_name: 'Gustavo',
    last_name: 'Regazio',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
  {
    id: 6,
    email: 'marcosbrenolcb@gmail.com',
    first_name: 'Marcos',
    last_name: 'Lemos',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
  {
    id: 7,
    email: 'luiza_assan@gmail.com',
    first_name: 'Luiza',
    last_name: 'Assanuma',
    avatar:
      'https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dmlld3xlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&w=1000&q=80',
  },
];

export default function App() {
  //função que renderiza cada item do FlatList
  function meuItem({ item }) {
    let nomeCompleto = item.first_name + ' ' + item.last_name;

    return <Pessoa nome={nomeCompleto} link={item.avatar} email={item.email} />;
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={meuItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 12,
    padding: 12,
    fontSize: 18,
    textShadowColor: '#aaa',
    textShadowRadius: 5,
    textAlign: 'center',
    backgroundColor: 'white',
    borderRadius: 5,
  },
  tinyLogo: {
    width: 80,
    height: 80,
    alignSelf: 'center',
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
